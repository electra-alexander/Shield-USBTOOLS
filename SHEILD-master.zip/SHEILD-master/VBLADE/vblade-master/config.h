#define _FILE_OFFSET_BITS 64 
typedef unsigned long long u64;
