#include <stdio.h>

int main(void)
{
	u64 n;
	printf("%d\n", (int) n+2);
	return 0;
}
